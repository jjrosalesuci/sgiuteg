<?php

namespace app\modules\mod_academico;

class Academico extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\mod_academico\controllers';

    public function init()
    {
        parent::init();
    }
}
