<?php
  $this->registerJsFile('@web/js/modules/mod_academico/informe.js',['depends' => ['app\assets\AppAsset']]);
?>